from django.http import JsonResponse
from django.views.decorators.http import require_POST
from django.contrib.auth.decorators import login_required
from django.shortcuts import get_object_or_404
from .models import Course, Score, Student, Teacher, Manager

@require_POST
@login_required
def submit_score(request):
    COURSE_ID = request.POST.get('course_id')
    STUDENT_ID = request.POST.get('student_id')
    EXAM_ID = request.POST.get('exam_id')
    SCORE = request.POST.get('score')
    
    user = request.user
    
    try:
        teacher = Teacher.objects.get(TEACHER_ID=user.TEACHER_ID)
    except Teacher.DoesNotExist:
        return JsonResponse({'message': 'Current user is not a teacher \n No permission to upload scores'})
    
    try:
        course = Course.objects.get(id=COURSE_ID, TEACHER_ID=teacher.TEACHER_ID)
    except Course.DoesNotExist:
        return JsonResponse({'message': 'The course does not exist'})
    
    try:
        student = Student.objects.get(id=STUDENT_ID, courses__id=COURSE_ID)
    except Student.DoesNotExist:
        return JsonResponse({'message': 'The student did not take this course'})
    
    score_obj, created = Score.objects.update_or_create(
        student_id=STUDENT_ID, 
        course_id=COURSE_ID, 
        exam_id=EXAM_ID, 
        defaults={'score': SCORE}
    )
    
    response_data = {'message': 'Results submitted successfully'}
    return JsonResponse(response_data)