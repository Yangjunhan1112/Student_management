from django.urls import path

from apps.Teacher.views import submit_score

urlpatterns = [
    path('submit_score/', submit_score, name='submit_score'),
]
