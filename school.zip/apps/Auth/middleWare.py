from django.shortcuts import redirect
from django.urls import reverse
from django.contrib.auth import logout

class LoginRequiredMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        response = self.get_response(request)
        current_url = request.path

        if current_url == '/login/' and request.user.is_authenticated:
            return redirect('home') 
        
        
        if current_url != '/login/' and not request.user.is_authenticated:
            request.session['next'] = current_url
            return redirect(reverse('login')) 
        
        return response
