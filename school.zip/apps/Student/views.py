from django.shortcuts import render
from django.http import JsonResponse
from .models import Course, Score, Exam

def get_scores(request):
    if request.method == 'POST':
        course_id = request.POST.get('course_id')
        user = request.user

        try:
            course = Course.objects.get(COURSE_ID=course_id)
        except Course.DoesNotExist:
            return JsonResponse({'error': 'The course does not exist'})

        if not Score.objects.filter(COURSE_ID=course_id, STUDENT_ID=user.STUDENT_ID).exists():
            return JsonResponse({'error': 'Current user did not select this course'})

        scores = Score.objects.filter(COURSE_ID=course_id, STUDENT_ID=user.STUDENT_ID)

        if not scores:
            return JsonResponse({'error': 'Results for this course are not yet available'})

        scores_dict = [{'exam_id': score.EXAM_ID, 'score': score.SCORE} for score in scores]

        return JsonResponse({'scores': scores_dict})

    return render(request, 'get_scores.html')