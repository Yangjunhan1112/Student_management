from django.db import models
# Create your models here.
class Student(models.Model):
    STUDENT_ID =  models.IntegerField(unique = True)
    NAME = models.CharField(max_length= 128)
    AGE = models.IntegerField(max_length=64)
    PASSWORD = models.CharField(max_length=128)
    GENDER = models.Choices[("male", "Male"), ("female", "Female")]
    PHONE_NUMBER = models.TextField(max_length=32)
    EMAIL = models.TextField()