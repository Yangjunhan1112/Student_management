from django.db import models
# Create your models here.

class Student(models.Model):
    STUDENT_ID = models.IntegerField(primary_key=True)
    NAME = models.CharField(max_length=50)
    AGE = models.IntegerField()
    PASSWORD = models.CharField(max_length=50)
    GENDER = models.Choices[("male", "Male"), ("female", "Female")]
    PHONE_NUMBER = models.CharField(max_length=20)
    EMAIL = models.EmailField()  

    