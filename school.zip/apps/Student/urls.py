from django.urls import path
from apps.Student.views import get_scores



urlpatterns = [
    path('get_scores/', get_scores, name='get_scores'),
]