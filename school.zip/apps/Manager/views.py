from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from . import Student, Course, StudentCourse

#选课的逻辑#
@csrf_exempt
def select_courses(request):
    if  request.method == "POST":
        STUDENT_ID = request.POST.get("student_id")
        courses = request.POST.getlist("courses")
        student = Student.objects.get(pk=STUDENT_ID)
        for COURSE_ID in courses:
            course = Course.objects.get(pk=COURSE_ID)
            student_course = StudentCourse(student=student, course=course)
            student_course.save()
        return JsonResponse({"status": "success"})
    else:
        return JsonResponse({"status": "error", "message": "You have already selected this course"})