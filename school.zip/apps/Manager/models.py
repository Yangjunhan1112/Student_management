from django.db import models
from . import Teacher
from . import Student
from . import Course

class Manager(models.Model):
    manager_ID = models.IntegerField(primary_key=True)
    NAME = models.CharField(max_length=50)
    AGE = models.IntegerField()
    PASSWORD = models.CharField(max_length=50)
    GENDER = models.Choices[("male", "Male"), ("female", "Female")]
    PHONE_NUMBER = models.CharField(max_length=20)
    EMAIL = models.EmailField()

class Course(models.Model):
    COURSE_ID = models.IntegerField(primary_key=True)
    TEACHER_ID = models.ForeignKey(Teacher, on_delete=models.CASCADE)
    COURSE_NAME = models.CharField(max_length=50)
    DESCRIPTION = models.TextField()
    SCHEDULE = models.CharField(max_length=50)
    SALARY_AMOUNT = models.DecimalField(max_digits=10, decimal_places=2)

class Finance(models.Model):
    ORDER_ID = models.IntegerField(primary_key=True)
    STUDENT_ID = models.ForeignKey(Student, on_delete=models.CASCADE)
    PAYMENT_DATE = models.DateField()
    T_AMOUNT = models.DecimalField(max_digits=10, decimal_places=2) 

class Score(models.Model):
    STUDENT_ID = models.ForeignKey(Student, on_delete=models.CASCADE)
    COURSE_ID = models.ForeignKey(Course, on_delete=models.CASCADE)
    EXAM_ID = models.IntegerField()
    SCORE = models.DecimalField(max_digits=10, decimal_places=2)    
    
class CourseSelection(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    course = models.ForeignKey(Course, on_delete=models.CASCADE)

    class Meta:
        unique_together = (("student", "course"),)    