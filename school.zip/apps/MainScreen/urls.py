from django import urls, views


urlpatterns = [
    urls(r'^$', views.index, name = 'index'),
   ] 