from csv import reader
from django.http import HttpRequest, HttpResponse
from django.shortcuts import redirect
from django.views import View
from apps.Auth.middleWare import LoginRequiredMiddleware

def index(request):
    return redirect("apps\mainScreen\templates")

