import React from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faHashtag, faTrashAlt } from "@fortawesome/free-solid-svg-icons";

function ManageTeacherPage() {
    
    const sampleData = {
      success: true,
      error_code: 0,
      description: " ",
      info: [
        {
          id: 1,
          first_name: "John",
          last_name: "Doe",
          email: "john.doe@example.com",
        },
  
        {
          id: 2,
          first_name: "Jane",
          last_name: "Doe",
          email: "jane.doe@example.com",
        },
        {
          id: 3,
          first_name: "Bob",
          last_name: "Smith",
          email: "bob.smith@example.com",
        },
  
        {
          id: 4,
          first_name: "Alice",
          last_name: "Johnson",
          email: "alice.johnson@example.com",
        },
        {
          id: 5,
          first_name: "Sam",
          last_name: "Brown",
          email: "sam.brown@example.com",
        },
      ],
    };
    
   
    
    return (
      <div className="container">
        <div className="row justify-content-center">
          <div className="col-12 col-sm-12">
            <div className="card my-2">
              <div className="card-body text-left">
                <p className="card-title display-6 gray text-center ">
                  Manage Teacher
                </p>
                <hr />
                <div className="row">
                  <div className="col px-4">
                  <div className="row list-card pt-3"
          key={0}
        >
          <div className="col text-center">
            <p>ID</p>
          </div>
          <div className="col-3 text-center">
            <p className="">First Name</p>
          </div>
          <div className="col text-center">
            <p className="">Last Name</p>
          </div>
          <div className="col text-center">
            <p className="">Email</p>
          </div>
          
          <div className="col text-center">
            <p className="">Remove</p>
          </div>
        </div>
                      
        {sampleData.info.map((element) => {
            return (
              <div
                className="row list-card1 pt-3"
                key={element.id}
                //   onClick={() => navigate(`/action/${element.id}`)}
              >
                <div className="col text-center">
                  <p>
                    <FontAwesomeIcon icon={faHashtag} /> {element.id}
                  </p>
                </div>
                <div className="col-3 text-center">
                  <p className="name">{element.first_name}</p>
                </div>
                <div className="col text-center">
                  <p className="">{element.last_name}</p>
                </div>
                <div className="col text-center">
                  <p className="">{element.email}</p>
                </div>
                <div
                className="col text-center "
                
              >
                <p className="delete">
                  <FontAwesomeIcon icon={faTrashAlt} color="red" />
                </p>
              </div>

                
              </div>
            );
          })}  
                      
                      
                    
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
  

  
  export default ManageTeacherPage;
  