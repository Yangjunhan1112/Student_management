import React from 'react'
import { useNavigate } from "react-router-dom";
import { useState } from "react";
import Banner from "../Images/banner.svg";
import Course1 from "../Images/course1.svg";
import Course2 from "../Images/course2.svg";
import Course3 from "../Images/course3.svg";

function TeacherHomePage() {
  const navigate = useNavigate();

  const [name, setName] = useState("Maria");
  const [gender, setGender] = useState("female");
  const [email, setEmail] = useState("00@gmail");
  const [phone, setPhone] = useState("1234");

  const courses = [
    { name: "Course A", image: Course1, description:"description123" },
    { name: "Course B", image: Course2, description:"description123" },
    { name: "Course C", image: Course3, description:"description123" },
  ];

  return (
    <div className="container">

      <div className="row">
        <div className="col-md-12">
          <div className="text-center">
            <h1>Online Education System</h1>
          </div>
        </div>
      </div>
      <div className="row justify-content-center">
        <div className="col-md-12">
          <div className="text-center">
            {/* <img src="../Images/head.svg" alt="banner" className="img-fluid" /> */}
            <img
                src={Banner}
                width="1600"
                height="200"
                className=""
                alt="banner"
              />
          </div>
        </div>
      </div>
    
      


      <div className="row justify-content-center">
        <div className="col-md-6">
          <div className="card">
            <div className="card-header">
              <h4>Teacher details</h4>
            </div>
            <div className="card-body">
              <form>
                {/* <button type="submit" className="btn btn-primary float-right">
                  Edit Profile
                </button> */}
                <div className="mb-3">
                  <label htmlFor="name" className="form-label">
                    Name:
                  </label>
                  <input
                    type="text"
                    className="form-control"
                    id="name"
                    value={name}
                    readOnly
                  />
                </div>
                <div className="mb-3">
                  <label htmlFor="gender" className="form-label">
                    Gender:
                  </label>
                  <input
                    type="text"
                    className="form-control"
                    id="gender"
                    value={gender}
                    readOnly
                  />
                </div>
                <div className="mb-3">
                  <label htmlFor="email" className="form-label">
                    Email:
                  </label>
                  <input
                    type="email"
                    className="form-control"
                    id="email"
                    value={email}
                    readOnly
                  />
                </div>
                <div className="mb-3">
                  <label htmlFor="phone" className="form-label">
                    Phone:
                  </label>
                  <input
                    type="tel"
                    className="form-control"
                    id="phone"
                    value={phone}
                    readOnly
                  />
                </div>

              </form>
            </div>
            <div className="card-footer">
              {/* <button className="btn btn-secondary">Pay Tuition</button> */}
              
            </div>
            <button
                  onClick={() => navigate("/edit")}
                  className="button button1 mb-3"
                >
                  Edit
                </button>
          </div>
        </div>
        <div className="col-md-6">

          <div className="card">
            <div className="card-header">
              <h4>Courses</h4>
            </div>
            <div className="card-body">
              <ul className="list-group list-group-flush">
                {courses.map((course, index) => (
                  <li className="list-group-item" key={index}>
                    <div className="row">
                      <div className="col-md-4">
                        <img
                          src={course.image}
                          width="100"
                          height="75"
                          className=""
                          alt={course.name}
                        />
                      </div>
                      <div className="col-md-8">
                        <a href="./stucourse" class="course-link">
                          <h5>{course.name}</h5>
                        </a>
                        <p>{course.description}</p>
                      </div>
                   </div>
                  </li>
                ))}
              </ul>
            </div>
            <button
                onClick={() => navigate("/stupay")}
                className="button button1 mb-3">
                  Receive Salary
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default TeacherHomePage