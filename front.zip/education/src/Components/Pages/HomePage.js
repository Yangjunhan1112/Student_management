import React from 'react'
import StudentHomePage from './StudentHomePage'
import ManagerHomePage from './ManagerHomePage'
import TeacherHomePage from './TeacherHomePage'

function HomePage() {
  let user = { type: "student"}
  if (user.type === "student")
    return (
      <StudentHomePage/>
    )
  else if (user.type === "manager")
    return (
      <ManagerHomePage/>
    )
  else if (user.type === "teacher")
    return (
      <TeacherHomePage/>
    )
}

export default HomePage