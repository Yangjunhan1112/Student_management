import React from "react";
import { Routes, Route } from "react-router-dom";
import ProtectedRoute from "../Shared/ProtectedRoute";


import HomePage from "./HomePage";
import LoginPage from "./LoginPage";
import EditPage from "./EditPage";

import StudentCoursePage from "./StudentCoursePage";
import StudentPayPage from "./StudentPayPage";
import ManageStudentPage from "./ManageStudentPage";
import FinanceShow from "./FinanceShow";

function Main() {
  return (
    <div className="app">
      <Routes>
        <Route path="/login" element={<LoginPage />} />
        <Route path="/edit" element={<EditPage />} />
        <Route path="/msp" element={<ManageStudentPage />} />
        <Route path="/finance" element={<FinanceShow />} />
        <Route path="/" element={<ProtectedRoute />}>
          <Route path="/" element={<HomePage />} />
          <Route path="/stucourse" element={<StudentCoursePage />} />
          <Route path="/stupay" element={<StudentPayPage />} />
          
          
        </Route>
        <Route
          path="*"
          element={
            <div>
              <p>Page not found!</p>
            </div>
          }
        />
      </Routes>
    </div>
  );
}

export default Main;
