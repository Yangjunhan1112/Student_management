import React from 'react'

function StudentPayPage() {
  return (
    <div>StudentPayPage</div>
  )
}

export default StudentPayPage