import React from 'react'

function StudentCoursePage() {
  return (
    <div>StudentCoursePage</div>
  )
}

export default StudentCoursePage