import React, { useEffect, useRef } from "react";
import { Chart } from "chart.js";

function FinanceShow() {
  const data = {
    tuitionFees: [
      1000, 1200, 1100, 1300, 1400, 1500,
      1600, 1700, 1800, 1900, 2000, 2100,
    ],
    teacherSalaries: [
      5000, 5500, 6000, 6500, 7000, 7500,
      8000, 8500, 9000, 9500, 10000, 10500,
    ],
  };

  const chartRef = useRef(null);

  useEffect(() => {
    const chartCanvas = chartRef.current.getContext("2d");

    new Chart(chartCanvas, {
      type: "bar",
      data: {
        labels: [
          "January", "February", "March", "April",
          "May", "June", "July", "August",
          "September", "October", "November", "December",
        ],
        datasets: [
          {
            label: "Tuition fees paid by students",
            data: data.tuitionFees,
            backgroundColor: "rgba(255, 99, 132, 0.2)",
            borderColor: "rgba(255, 99, 132, 1)",
            borderWidth: 1,
          },
          {
            label: "Salaries paid to teachers",
            data: data.teacherSalaries,
            backgroundColor: "rgba(54, 162, 235, 0.2)",
            borderColor: "rgba(54, 162, 235, 1)",
            borderWidth: 1,
          },
        ],
      },
      options: {
        scales: {
          yAxes: [
            {
              ticks: {
                beginAtZero: true,
              },
            },
          ],
        },
      },
    });
  }, [data]);

  return (
    <div className="container">
      <div className="row justify-content-center">
        <div className="col-12 col-sm-12">
          <div className="card my-2">
            <div className="card-body text-left">
              <p className="card-title display-6 gray text-center">
                Dashboard
              </p>
              <hr />
              <div className="row my-4 justify-content-center">
                <div className="col-12 col-sm-12">
                  <canvas ref={chartRef} />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default FinanceShow;
